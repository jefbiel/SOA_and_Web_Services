package br.com.fiap3espa.auto_escola_3espa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutoEscola3EspaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutoEscola3EspaApplication.class, args);
	}

}
