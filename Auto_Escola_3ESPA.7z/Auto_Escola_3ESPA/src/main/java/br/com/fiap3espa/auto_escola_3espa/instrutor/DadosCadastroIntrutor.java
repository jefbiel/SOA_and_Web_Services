package br.com.fiap3espa.auto_escola_3espa.instrutor;


import br.com.fiap3espa.auto_escola_3espa.endereco.DadosEndereco;

public record DadosCadastroIntrutor(
        String nome,
        String email,
        String cnh,
        String especialidade,
        DadosEndereco endereco
) {


}
