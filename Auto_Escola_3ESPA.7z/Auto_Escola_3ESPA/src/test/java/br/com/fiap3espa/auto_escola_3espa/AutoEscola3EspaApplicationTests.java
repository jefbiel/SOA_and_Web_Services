package br.com.fiap3espa.auto_escola_3espa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutoEscola3EspaApplicationTests {

	@Test
	void contextLoads() {
	}

}
